-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2023 at 06:02 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `postpulse`
--

-- --------------------------------------------------------

--
-- Table structure for table `topic`
--

CREATE TABLE `topic` (
  `id_topic` int(11) NOT NULL,
  `nama_topic` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `topic`
--

INSERT INTO `topic` (`id_topic`, `nama_topic`) VALUES
(1, 'Baking'),
(2, 'Car'),
(3, 'Cooking'),
(4, 'Drawing'),
(5, 'Games'),
(6, 'Hairstyle'),
(7, 'K-Pop'),
(8, 'Make Up'),
(9, 'Sport');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(52) DEFAULT NULL,
  `email` varchar(52) DEFAULT NULL,
  `password` varchar(26) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `src` varchar(50) NOT NULL DEFAULT 'assets\\profileicon.png',
  `favoritsport` tinyint(1) NOT NULL DEFAULT 0,
  `favoritmakeup` tinyint(1) NOT NULL DEFAULT 0,
  `favoritkpop` tinyint(1) NOT NULL DEFAULT 0,
  `favorithairstyle` tinyint(1) NOT NULL DEFAULT 0,
  `favoritdrawing` tinyint(1) NOT NULL DEFAULT 0,
  `favoritbaking` tinyint(1) NOT NULL DEFAULT 0,
  `favoritcooking` tinyint(1) NOT NULL DEFAULT 0,
  `favoritcar` tinyint(1) NOT NULL DEFAULT 0,
  `favoritgame` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`, `description`, `src`, `favoritsport`, `favoritmakeup`, `favoritkpop`, `favorithairstyle`, `favoritdrawing`, `favoritbaking`, `favoritcooking`, `favoritcar`, `favoritgame`) VALUES
(1, 'eric', 'eric@gmail.com', '$2y$10$wJCC0aksD2dufD8I6lf', NULL, 'assets\\profileicon.png', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 'eric1', 'ericcw100@gmail.com', '$2y$10$38ywl9hsPNNjb40gt52', 'asjbfawoif', 'profilepicture/IMG_8974.JPG', 1, 1, 0, 0, 0, 0, 0, 0, 0),
(3, 'eric', 'eric123@gmail.com', '$2y$10$7ZwAksIbQH0eZD9V3wF', NULL, 'assets\\profileicon.png', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 'abc', 'abc@gmail.com', '$2y$10$c7T3PqFIoHNGRAPcowN', 'hai                      ', 'assets\\profileicon.png', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 'kevin', 'kevin@gmail.com', '$2y$10$e6DdAFU37a/Z/jPjYRi', NULL, 'assets\\profileicon.png', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_post`
--

CREATE TABLE `user_post` (
  `id_post` int(11) NOT NULL,
  `id_topic` int(11) NOT NULL,
  `data_images` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_post`
--

INSERT INTO `user_post` (`id_post`, `id_topic`, `data_images`) VALUES
(15, 7, 'BABYMONSTER -  BATTER UP  M_V TEASER.mp4'),
(17, 1, 'redvelvet cake.jpg'),
(18, 4, 'cat.jpg'),
(19, 2, 'tesla.jpg'),
(20, 7, 'yunjin.jpg'),
(21, 8, 'douyin.jpg'),
(22, 8, '1mp.jpg'),
(23, 6, 'undercut.jpg'),
(24, 3, 'corndog.jpg'),
(25, 3, 'taco.jpg'),
(26, 7, 'hanni.jpg'),
(27, 9, 'abs workout.jpg'),
(28, 3, 'garlic butter steak.jpg'),
(29, 2, 'pink car.jpg'),
(30, 6, 'hs1.jpg'),
(31, 5, 'spike.jpg'),
(32, 5, 'valorant.jpg'),
(33, 1, 'cookies strawberry.jpg'),
(34, 1, 'mille crepse oreo.jpg'),
(35, 1, 'brownies.jpg'),
(36, 7, 'jennie.jpg'),
(37, 9, 'jogging.jpg'),
(38, 1, 'cheesecake.jpg'),
(39, 5, 'apex.jpg'),
(40, 6, 'hime.jpg'),
(41, 9, 'tennis.jpg'),
(0, 2, 'Screenshot (187).png'),
(0, 3, 'Screenshot (187).png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `topic`
--
ALTER TABLE `topic`
  ADD PRIMARY KEY (`id_topic`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_post`
--
ALTER TABLE `user_post`
  ADD KEY `user_post_ibfk_1` (`id_topic`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `topic`
--
ALTER TABLE `topic`
  MODIFY `id_topic` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_post`
--
ALTER TABLE `user_post`
  ADD CONSTRAINT `user_post_ibfk_1` FOREIGN KEY (`id_topic`) REFERENCES `topic` (`id_topic`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
